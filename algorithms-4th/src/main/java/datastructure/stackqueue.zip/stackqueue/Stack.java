package datastructure.stackqueue;

public interface Stack {
    void push(Object obj);
    Object pop();
    boolean isEmpty();
    Object top();
}
